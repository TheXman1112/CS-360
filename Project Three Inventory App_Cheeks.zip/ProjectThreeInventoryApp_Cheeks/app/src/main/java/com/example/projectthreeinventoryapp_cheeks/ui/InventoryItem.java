package com.example.projectthreeinventoryapp_cheeks.ui;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projectthreeinventoryapp_cheeks.R;

import java.util.ArrayList;

public class InventoryItem extends RecyclerView.Adapter<InventoryItem.ViewHolder>{

    private Context context;
    private ArrayList inv_id, inv_name, inv_type, inv_count;
    Activity activity;

    InventoryItem(Activity activity, Context context,
                  ArrayList id,
                  ArrayList name,
                  ArrayList type,
                  ArrayList count) {
        this.activity = activity;
        this.context = context;
        this.inv_id = id;
        this.inv_name = name;
        this.inv_type = type;
        this.inv_count = count;
    }

    // Fills each row for recycler
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.inventory_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {

        holder.id.setText(String.valueOf(inv_id.get(position)));
        holder.name.setText(String.valueOf(inv_name.get(position)));
        holder.type.setText(String.valueOf(inv_type.get(position)));
        holder.count.setText(String.valueOf(inv_count.get(position)));

        holder.Layout.setOnClickListener(v -> {

        });

        // Edit item button for each item in recycler
        holder.itemView.findViewById(R.id.edit_item_button).setOnClickListener(v -> {
            Intent intent = new Intent(context, EditItemActivity.class);

            intent.putExtra("id", String.valueOf(inv_id.get(position)));
            intent.putExtra("name", String.valueOf(inv_name.get(position)));
            intent.putExtra("type", String.valueOf(inv_type.get(position)));
            intent.putExtra("count", String.valueOf(inv_count.get(position)));

            activity.startActivityForResult(intent, 1);
        });
    }

    @Override
    public int getItemCount() {
        return inv_id.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView id, name, type, count;
        LinearLayout Layout;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            Layout = itemView.findViewById(R.id.item_layout);
            id = itemView.findViewById(R.id.item_id);
            name = itemView.findViewById(R.id.item_name);
            type = itemView.findViewById(R.id.item_type);
            count = itemView.findViewById(R.id.item_count);
        }
    }
}
