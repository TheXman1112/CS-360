package com.example.projectthreeinventoryapp_cheeks.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class LoginDB extends SQLiteOpenHelper {

    public LoginDB(@Nullable Context context) {
        super(context, "LoginDB", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users(username TEXT PRIMARY KEY, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int j) {
        db.execSQL("DROP TABLE IF EXISTS users");
    }

    // Add new user to database
    public void insertData(String user, String pass) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", user);
        values.put("password", pass);
        db.insert("users", null, values);
    }

    // Check if username is already taken
    public Boolean checkUser(String user) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username = ?", new String[] {user});
        return cursor.getCount() > 0;
    }

    // Make sure username and password are correct
    public Boolean checkUserPass(String user, String pass) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username = ? AND password = ?", new String[] {user, pass});
        return cursor.getCount() > 0;
    }
}