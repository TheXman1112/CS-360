package com.example.projectthreeinventoryapp_cheeks.ui;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.projectthreeinventoryapp_cheeks.R;
import com.example.projectthreeinventoryapp_cheeks.data.InventoryDB;

public class AddItemActivity extends AppCompatActivity {
    EditText itemNameText, itemTypeText, itemCountText;
    Button addItemButton;

    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            // get the content of all three edit texts
            String itemName = itemNameText.getText().toString();
            String itemType = itemTypeText.getText().toString();
            String itemCount = itemCountText.getText().toString();

            // check whether all three fields are empty or not
            addItemButton.setEnabled(!itemName.isEmpty() && !itemType.isEmpty() && !itemCount.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.add_item);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.add), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        itemNameText = findViewById(R.id.add_item_name);
        itemTypeText = findViewById(R.id.add_item_type);
        itemCountText = findViewById(R.id.add_item_count);
        addItemButton = findViewById(R.id.add_button);

        itemNameText.addTextChangedListener(textWatcher);
        itemTypeText.addTextChangedListener(textWatcher);
        itemCountText.addTextChangedListener(textWatcher);

        // Add item into database
        addItemButton.setOnClickListener(v -> {
            InventoryDB db = new InventoryDB(AddItemActivity.this);

            db.addItem(itemNameText.getText().toString().trim(),
                      itemTypeText.getText().toString().trim(),
                    Integer.parseInt(itemCountText.getText().toString()));

            // Move back to Inventory screen
            finish();
        });
    }
}
