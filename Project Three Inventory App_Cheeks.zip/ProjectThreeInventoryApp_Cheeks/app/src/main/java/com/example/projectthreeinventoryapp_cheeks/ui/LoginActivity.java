package com.example.projectthreeinventoryapp_cheeks.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.projectthreeinventoryapp_cheeks.R;
import com.example.projectthreeinventoryapp_cheeks.data.LoginDB;

public class LoginActivity extends AppCompatActivity {

    EditText usernameText, passwordText;
    Button signInButton, registerButton;
    LoginDB DB;

    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            // Get the content of both the edit text
            String user = usernameText.getText().toString();
            String pass = passwordText.getText().toString();

            // Check whether both the fields are empty or not
            signInButton.setEnabled(!user.isEmpty() && !pass.isEmpty());
            registerButton.setEnabled(!user.isEmpty() && !pass.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.app_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.login), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        usernameText = findViewById(R.id.username);
        passwordText = findViewById(R.id.password);
        signInButton = findViewById(R.id.sign_in);
        registerButton = findViewById(R.id.register);

        DB = new LoginDB(this);

        usernameText.addTextChangedListener(textWatcher);
        passwordText.addTextChangedListener(textWatcher);

        signInButton.setOnClickListener(v -> {
            String user = usernameText.getText().toString();
            String pass = passwordText.getText().toString();
            Boolean check = DB.checkUserPass(user, pass);

            // Inform user of successful login and move to next screen
            if (check == true) {
                Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(LoginActivity.this, InventoryActivity.class));
            }
            // Inform user of failed login
            else {
                Toast.makeText(LoginActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
            }

        });

        registerButton.setOnClickListener(v -> {
            String user = usernameText.getText().toString();
            String pass = passwordText.getText().toString();
            Boolean checkUser = DB.checkUser(user);

            // If user doesn't already exist, adds the user to database and signs in
            if (checkUser == false) {
                DB.insertData(user, pass);
                Toast.makeText(LoginActivity.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(LoginActivity.this, InventoryActivity.class));
            }
            else {
                Toast.makeText(LoginActivity.this, "User Already Exists", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
