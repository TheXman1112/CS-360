package com.example.projectthreeinventoryapp_cheeks.data;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.BaseColumns;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;

import androidx.core.content.ContextCompat;

import java.util.Timer;
import java.util.TimerTask;

public class InventoryNotification {
    private Context context;
    private Timer timer;

    public InventoryNotification(Context context) {
        this.context = context;
        this.timer = new Timer();
    }

    private class Work extends TimerTask {
        private Context context;
        InventoryDB db;

        public Work(Context context) {
            this.context = context;
            this.db = new InventoryDB(this.context);
        }

        public void run() {
            db.getReadableDatabase();
            String[] projection = {
                    BaseColumns._ID,
                    "name",
                    "type",
                    "count"
            };

            // Filter results
            String selection = "count < ?";
            String[] selectionArgs = { "3" };

            Cursor cursor = db.queryInventoryDB(projection, selection, selectionArgs, null);
            Cursor data = db.displayData();

            // Iterate through items
            if (data != null && cursor.moveToFirst()) {
                do {
                    String productName = data.getString(data.getColumnIndexOrThrow("name"));
                    String productCount = data.getString(data.getColumnIndexOrThrow("count"));
                    String phoneNumber = null;

                    // Check permissions to get phone number
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                        TelephonyManager telephonyManager = (TelephonyManager)context.getSystemService(context.TELEPHONY_SERVICE);
                        phoneNumber = telephonyManager.getLine1Number();
                    }

                    // Check permissions to send SMS
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                        SmsManager smsManager = SmsManager.getDefault();
                        // Send SMS
                        smsManager.sendTextMessage(phoneNumber, null, productName + " only has " + productCount + " left, consider getting more.", null, null);
                    }
                    // Iterate to next item
                } while (data.moveToNext());
            }
            data.close();
        }
    }

    // Timer to make sure user isn't spammed with texts
    public void StartThread() {
        timer.schedule(new Work(this.context), 0, 60000);
    }
}
