package com.example.projectthreeinventoryapp_cheeks.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class InventoryDB extends SQLiteOpenHelper {

    private Context context;

    public InventoryDB(@Nullable Context context) {
        super(context, "InventoryDB", null, 1);
        this.context = context;
    }

    // Create inventory table
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE inventory(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, type TEXT, count INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int j) {
        db.execSQL("DROP TABLE IF EXISTS inventory");
    }

    // Displays all inventory data
    public Cursor displayData() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        if (db != null) {
            cursor = db.rawQuery("SELECT * FROM inventory", null);
        }
        return cursor;
    }

    // Add item to inventory database
    public void addItem(String name, String type, int count) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("name", name);
        values.put("type", type);
        values.put("count", count);

        long result = db.insert("inventory", null, values);

        if (result == -1) {
            Toast.makeText(context, "Failed To Add Item", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(context, "Item Added", Toast.LENGTH_SHORT).show();
        }
    }

    // Updates existing item in inventory database
    public void updateItem(String id, String name, String type, int count) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("name", name);
        values.put("type", type);
        values.put("count", count);

        long result = db.update("inventory", values, "id = ?", new String[] {id});

        if (result == -1) {
            Toast.makeText(context, "Update Failed", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(context, "Update Successful", Toast.LENGTH_SHORT).show();
        }
    }

    // Deletes item from inventory database
    public void deleteItem(String id) {
        SQLiteDatabase db = this.getWritableDatabase();

        long result = db.delete("inventory", "id = ?", new String[] {id});

        if (result == -1) {
            Toast.makeText(context, "Failed To Delete Item", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(context, "Item Deleted", Toast.LENGTH_SHORT).show();
        }
    }

    // Query and return cursor for items
    public Cursor queryInventoryDB(String[] projection, @Nullable String selection,
                                   @Nullable String[] selectionArgs, @Nullable String sortOrder) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                "inventory",
                projection,
                selection,
                selectionArgs,
                null,
                null,
                sortOrder
        );
    }
}
