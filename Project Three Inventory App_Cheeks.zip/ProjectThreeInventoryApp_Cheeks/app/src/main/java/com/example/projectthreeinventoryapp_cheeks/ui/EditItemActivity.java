package com.example.projectthreeinventoryapp_cheeks.ui;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.projectthreeinventoryapp_cheeks.R;
import com.example.projectthreeinventoryapp_cheeks.data.InventoryDB;

public class EditItemActivity extends AppCompatActivity {
    EditText newItemName, newItemType, newItemCount;
    String id, itemName, itemType, itemCount;
    Button editItemButton, deleteItemButton;

    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            // get the content of all three edit text
            String itemName = newItemName.getText().toString();
            String itemType = newItemType.getText().toString();
            String itemCount = newItemCount.getText().toString();

            // check whether all three fields are empty or not
            editItemButton.setEnabled(!itemName.isEmpty() && !itemType.isEmpty() && !itemCount.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.edit_item);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.edit), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        newItemName = findViewById(R.id.edit_item_name);
        newItemType = findViewById(R.id.edit_item_type);
        newItemCount = findViewById(R.id.edit_item_count);
        editItemButton = findViewById(R.id.edit_button);
        deleteItemButton = findViewById(R.id.delete_button);

        newItemName.addTextChangedListener(textWatcher);
        newItemType.addTextChangedListener(textWatcher);
        newItemCount.addTextChangedListener(textWatcher);

        getAndSetIntent();

        // Update item with new values
        editItemButton.setOnClickListener(v -> {
            InventoryDB db = new InventoryDB(EditItemActivity.this);

            db.updateItem(id, newItemName.getText().toString().trim(),
                    newItemType.getText().toString().trim(),
                    Integer.parseInt(newItemCount.getText().toString()));
            // Move back to Inventory screen
            finish();
        });

        // Delete item from database
        deleteItemButton.setOnClickListener(v -> {
            InventoryDB db = new InventoryDB(EditItemActivity.this);

            db.deleteItem(id);

            // Move back to Inventory screen
            finish();
        });


    }

    // Set new values to update item
    void getAndSetIntent() {
        if (getIntent().hasExtra("id") && getIntent().hasExtra("name") &&
                getIntent().hasExtra("type") && getIntent().hasExtra("count")) {

            id = getIntent().getStringExtra("id");
            itemName = getIntent().getStringExtra("name");
            itemType = getIntent().getStringExtra("type");
            itemCount = getIntent().getStringExtra("count");

            newItemName.setText(itemName);
            newItemType.setText(itemType);
            newItemCount.setText(itemCount);
        }
        else {
            Toast.makeText(this, "No Update", Toast.LENGTH_SHORT).show();
        }
    }
}
