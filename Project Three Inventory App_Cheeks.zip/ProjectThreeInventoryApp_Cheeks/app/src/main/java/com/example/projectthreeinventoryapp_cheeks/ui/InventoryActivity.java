package com.example.projectthreeinventoryapp_cheeks.ui;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projectthreeinventoryapp_cheeks.R;
import com.example.projectthreeinventoryapp_cheeks.data.InventoryDB;
import com.example.projectthreeinventoryapp_cheeks.data.InventoryNotification;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.Map;

public class InventoryActivity extends AppCompatActivity {

    RecyclerView recycler;
    FloatingActionButton fab;
    Switch smsSwitch;
    InventoryDB db;
    InventoryItem Adapter;
    ArrayList<String> id, name, type, count;
    private InventoryNotification notification;
    private ActivityResultLauncher<String[]> requestPermission;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.inventory_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.inventory), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        recycler = findViewById(R.id.inventory_data);
        fab = findViewById(R.id.add_item_button);
        smsSwitch = findViewById(R.id.sms_permissions);
        notification = new InventoryNotification(InventoryActivity.this);

        // Moves to add item screen
        fab.setOnClickListener(v -> {
            startActivity(new Intent(InventoryActivity.this, AddItemActivity.class));
        });

        // Check if switch is enabled
        smsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Enabled
            if (isChecked) {
                // Check Permissions
                if (ContextCompat.checkSelfPermission(InventoryActivity.this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED &&
                        ContextCompat.checkSelfPermission(InventoryActivity.this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED &&
                        ContextCompat.checkSelfPermission(InventoryActivity.this, Manifest.permission.READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED) {
                    notification.StartThread();
                }
                else {
                    // Request permissions
                    requestPermission.launch(new String[] {Manifest.permission.SEND_SMS, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_PHONE_NUMBERS});
                }
            }
            else {
                // Disable if activated
                notification.StartThread();
            }
        });

        requestPermission = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), permissions -> {
            Boolean failed = false;
            for (Map.Entry<String, Boolean> item : permissions.entrySet()) {
                // Continue if permission is granted
                if (item.getValue()) {
                    continue;
                }
                Toast.makeText(InventoryActivity.this, "Denied", Toast.LENGTH_SHORT).show();
                failed = true;
            }

            if (failed) {
                smsSwitch.setChecked(false);
            }
        });

        // Create arrays
        db = new InventoryDB(InventoryActivity.this);
        id = new ArrayList<>();
        name = new ArrayList<>();
        type = new ArrayList<>();
        count = new ArrayList<>();

        // Store data in arrays
        storeData();

        // Build the rows for each item
        Adapter = new InventoryItem(InventoryActivity.this, this, id, name, type, count);
        recycler.setAdapter(Adapter);
        recycler.setLayoutManager(new LinearLayoutManager(InventoryActivity.this));

    }

    @Override
    protected void onActivityResult(int request, int result, @Nullable Intent data) {
        super.onActivityResult(request, result, data);
        if (request == 1) {
            recreate();
        }
    }

    // Create rows for each item in recycler
    void storeData() {
        Cursor cursor = db.displayData();

        while (cursor.moveToNext()) {
            id.add(cursor.getString(0));
            name.add(cursor.getString(1));
            type.add(cursor.getString(2));
            count.add(cursor.getString(3));
        }
    }
}